# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

python3 commandLineMusicVideo/__init__.py -songs "../../../Soulseek Downloads/complete/M.Riky/starsky & hutch (season one) - lalo schifrin, jack elliott"/ mp3 "front.jpg" -outputResolution 1920:1080 -removeFirst 4 -removeAfter "-" -titleize



